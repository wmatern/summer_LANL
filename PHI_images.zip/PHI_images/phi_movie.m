writerObj = VideoWriter('phi_movie.avi');
writerObj.FrameRate = 15;
open(writerObj);
for i = 1:48
    A = imread(['phi_',num2str(i),'.png']);
    imshow(A);
    F = getframe;
    writeVideo(writerObj,F);
end
close(writerObj);